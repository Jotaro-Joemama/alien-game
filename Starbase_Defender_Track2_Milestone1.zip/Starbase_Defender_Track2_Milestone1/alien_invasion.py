"""Program Name: Starbase Defender - Track 2 Milestone 1
Author: Makaden Eveland
Purpose: Run the custom ship, space background, laser, and firing-sound prototype.
Starter Code Links: https://github.com/Jotaro-Joemama/alien-game
Date Updated: November 15, 2026

Milestone 1 isolation: no alien fleet, alien collision logic, scoring, HUD,
or Play button is imported or run in this build.
"""

from pathlib import Path
import sys

import pygame
from pygame.sprite import Group

from settings import Settings
from ship import Ship
from bullet import Bullet


class AlienInvasion:
    """Manage the Milestone 1 custom-assets prototype."""

    def __init__(self):
        """Initialize Pygame, load the custom assets, and create the player."""
        pygame.init()
        pygame.mixer.init()
        self.settings = Settings()
        self.screen = pygame.display.set_mode(
            (self.settings.screen_width, self.settings.screen_height)
        )
        pygame.display.set_caption("Starbase Defender - Track 2")
        self.clock = pygame.time.Clock()

        asset_dir = Path(__file__).resolve().parent / "Assets"
        background_path = asset_dir / "images" / "Starbasesnow.png"
        self.background = pygame.image.load(str(background_path)).convert()
        self.background = pygame.transform.smoothscale(
            self.background,
            (self.settings.screen_width, self.settings.screen_height),
        )

        laser_sound_path = asset_dir / "sound" / "laser.mp3"
        self.laser_sound = pygame.mixer.Sound(str(laser_sound_path))
        self.laser_sound.set_volume(0.45)

        self.ship = Ship(self)
        self.bullets = Group()

    def run_game(self):
        """Run the game loop until the player closes the window."""
        while True:
            self._check_events()
            self.ship.update()
            self._update_bullets()
            self._update_screen()
            self.clock.tick(self.settings.frame_rate)

    def _check_events(self):
        """Handle window events, movement keys, firing, and quitting."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self._quit_game()
            elif event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_q, pygame.K_ESCAPE):
                    self._quit_game()
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.ship.moving_right = True
                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    self.ship.moving_left = True
                elif event.key == pygame.K_SPACE:
                    self._fire_bullet()
            elif event.type == pygame.KEYUP:
                if event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.ship.moving_right = False
                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    self.ship.moving_left = False

    def _fire_bullet(self):
        """Fire a laser if the maximum number of on-screen lasers is not reached."""
        if len(self.bullets) < self.settings.bullets_allowed:
            self.bullets.add(Bullet(self))
            self.laser_sound.play()

    def _update_bullets(self):
        """Move lasers and remove them after they leave the top of the screen."""
        self.bullets.update()
        for bullet in list(self.bullets):
            if bullet.rect.bottom <= 0:
                self.bullets.remove(bullet)

    def _update_screen(self):
        """Draw the background, ship, and lasers, then refresh the display."""
        self.screen.blit(self.background, (0, 0))
        self.ship.draw()
        for bullet in self.bullets:
            bullet.draw()
        pygame.display.flip()

    @staticmethod
    def _quit_game():
        """Shut down Pygame and exit the application."""
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    game = AlienInvasion()
    game.run_game()
