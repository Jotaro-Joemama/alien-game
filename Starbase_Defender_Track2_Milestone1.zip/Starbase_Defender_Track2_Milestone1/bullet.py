"""Program Name: Starbase Defender - Track 2 Milestone 1
Author: Makaden Eveland
Purpose: Create and update the custom laser projectile.
Starter Code Links: https://github.com/Jotaro-Joemama/alien-game
Date Updated: November 15, 2026
"""

from pathlib import Path

import pygame


class Bullet(pygame.sprite.Sprite):
    """Represent the custom laser projectile fired by the player."""

    def __init__(self, game):
        """Load the laser image and position it above the player's ship."""
        super().__init__()
        self.screen = game.screen
        self.settings = game.settings
        image_path = Path(__file__).resolve().parent / "Assets" / "images" / "laserBlast.png"
        self.image = pygame.image.load(str(image_path)).convert_alpha()
        self.image = pygame.transform.smoothscale(self.image, (22, 42))
        self.rect = self.image.get_rect()
        self.rect.midbottom = game.ship.rect.midtop
        self.y = float(self.rect.y)

    def update(self):
        """Move the laser upward according to the configured speed."""
        self.y -= self.settings.bullet_speed
        self.rect.y = round(self.y)

    def draw(self):
        """Draw the custom laser image on the game screen."""
        self.screen.blit(self.image, self.rect)
