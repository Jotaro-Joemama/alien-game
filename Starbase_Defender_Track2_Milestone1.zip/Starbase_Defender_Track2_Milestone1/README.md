# Starbase Defender — Track 2, Milestone 1

**Author:** Makaden Eveland  
**Track:** 2 — Custom Game Assets  
**Milestone:** 1 — Core Player Assets & Theme  
**Updated:** November 15, 2026

## Milestone 1 scope

This build demonstrates the custom player ship, space background, laser projectile,
and laser firing sound. It intentionally does **not** run the alien fleet, alien
collisions, score display, HUD, game-over screen, or Play button. Those belong to
later milestones.

## Run the game

1. Install Python.
2. Open a terminal in this folder.
3. Install the dependency: `python -m pip install -r requirements.txt`
4. Start the game: `python alien_invasion.py`

## Controls

- Left / Right arrows or A / D: move the ship
- Space: fire a laser (plays the custom laser sound)
- Q or Escape: quit

## Custom assets

- `Assets/images/ship.png` — player ship
- `Assets/images/Starbasesnow.png` — space background
- `Assets/images/laserBlast.png` — laser projectile
- `Assets/sound/laser.mp3` — laser firing sound

All game asset paths are built with `pathlib.Path`.

## Milestone 1 demonstration checklist (maximum 2 minutes)

1. Show the game window and its caption: **Starbase Defender - Track 2**.
2. Explain the theme and show the custom space background.
3. Move the custom ship left and right.
4. Fire several lasers so the custom projectile and firing sound are clear.
5. Briefly explain that `ship.py`, `bullet.py`, and `alien_invasion.py` load assets
   using `pathlib`.
6. Show that no alien fleet, HUD, scoring, or Play button is active in this M1 build.

## GitHub submission checklist

- Create and work on branch `track_2_assets`.
- Commit changes in logical steps; do not make one giant final commit.
- Keep `requirements.txt` and `.gitignore` in the repository.
- Add the unlisted YouTube URL below after recording.

**Milestone_1_Demo:** _Paste your unlisted YouTube URL here._

## Suggested commit sequence

1. `Create Track 2 assets milestone branch`
2. `Add custom player ship and space background`
3. `Add custom laser projectile and firing sound`
4. `Isolate later milestone systems and document M1`
5. `Verify Milestone 1 build and README demo checklist`
