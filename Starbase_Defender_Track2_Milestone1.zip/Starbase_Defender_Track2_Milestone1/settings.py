"""Program Name: Starbase Defender - Track 2 Milestone 1
Author: Makaden Eveland
Purpose: Store display, movement, and projectile settings for the custom-assets prototype.
Starter Code Links: https://github.com/Jotaro-Joemama/alien-game
Date Updated: November 15, 2026
"""


class Settings:
    """Store configuration values used by the Milestone 1 game."""

    def __init__(self):
        """Initialize the game window and player projectile settings."""
        self.screen_width = 1000
        self.screen_height = 700
        self.frame_rate = 60
        self.ship_speed = 5.0
        self.bullet_speed = 8.0
        self.bullets_allowed = 4
        self.background_color = (5, 8, 28)
