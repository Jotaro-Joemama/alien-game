"""Program Name: Starbase Defender - Track 2 Milestone 1
Author: Makaden Eveland
Purpose: Load, position, and move the custom player ship.
Starter Code Links: https://github.com/Jotaro-Joemama/alien-game
Date Updated: November 15, 2026
"""

from pathlib import Path

import pygame


class Ship:
    """Represent the player-controlled ship and its movement."""

    def __init__(self, game):
        """Load the custom ship image and place it at the bottom center."""
        self.screen = game.screen
        self.settings = game.settings
        image_path = Path(__file__).resolve().parent / "Assets" / "images" / "ship.png"
        self.image = pygame.image.load(str(image_path)).convert_alpha()
        self.image = pygame.transform.smoothscale(self.image, (72, 50))
        self.rect = self.image.get_rect()
        self.screen_rect = self.screen.get_rect()
        self.rect.midbottom = (self.screen_rect.centerx, self.screen_rect.bottom - 18)
        self.x = float(self.rect.x)
        self.moving_right = False
        self.moving_left = False

    def update(self):
        """Move horizontally while keeping the ship inside the screen."""
        if self.moving_right:
            self.x += self.settings.ship_speed
        if self.moving_left:
            self.x -= self.settings.ship_speed
        max_x = self.screen_rect.right - self.rect.width
        self.x = max(0, min(self.x, max_x))
        self.rect.x = round(self.x)

    def draw(self):
        """Draw the custom ship image at its current position."""
        self.screen.blit(self.image, self.rect)
